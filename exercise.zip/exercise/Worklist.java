package exercise;

public interface Worklist {
	void add(String item);
	boolean hasMore();
	String remove();
}
