package workshop05;

public class EmptyWorklistException extends Exception {

	public EmptyWorklistException(String message) {
		super("The " + message +  " is empty.");
	}
}
